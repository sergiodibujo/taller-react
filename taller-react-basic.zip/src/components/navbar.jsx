import React from 'react'
import Container from 'react-bootstrap/Container';
import {Nav, Navbar} from 'react-bootstrap';

// const NavBarPage = () => {
//   return (
//     <>
//       <N avbar bg="primary" data-bs-theme="dark">
//         <Container>
//           <Navbar.Brand href="#home">Navbar</Navbar.Brand>
//           <Nav className="me-auto">
//             <Nav.Link href="#home">Home</Nav.Link>
//             <Nav.Link href="#features">Features</Nav.Link>
//             <Nav.Link href="#pricing">Pricing</Nav.Link>
//           </Nav>
//         </Container>
//       </N>

//     </>
//   );
// }

export const NavBarComponent = ({children}) => {
    return (
        <Navbar bg="primary" data-bs-theme="dark">
            <Container>
                {children}
            </Container>
        </Navbar>
    );
}

export const NavBarBrandComponent = ({href, children}) => {
    return (
        <Navbar.Brand href={href}>
            {children}
        </Navbar.Brand>
    );
}

export const NavComponent = ({className, children}) => {
    return (
        <Nav className={className}>
            {children}
        </Nav>
    );
}

export const NavItemComponent = ({href, children}) => {
    return (
        <Nav.Link href={href}>{children}</Nav.Link>
    )
}
// export default NavBarPage;