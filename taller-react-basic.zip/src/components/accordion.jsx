import React from 'react'
import Accordion from 'react-bootstrap/Accordion';

// function AccordionPage() {
//   return (
//     <Accordion defaultActiveKey="0">
//       <Accordion.Item eventKey="0">
//         <Accordion.Header>Accordion Item #1</Accordion.Header>
//         <Accordion.Body>
//           Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
//           eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
//           minim veniam.
//         </Accordion.Body>
//       </Accordion.Item>
//       <Accordion.Item eventKey="1">
//         <Accordion.Header>Accordion Item #2</Accordion.Header>
//         <Accordion.Body>
//           Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
//           eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
//           minim veniam.
//         </Accordion.Body>
//       </Accordion.Item>
//     </Accordion>
//   );
// }

// export const default AccordionPage;





export const AccordionComponent = ({children, defaultActiveKey}) => {
    return (
        <Accordion defaultActiveKey={defaultActiveKey}>
            {children}
        </Accordion>
    )
}

export const AccordionItemComponent = ({children, eventKey} ) => {
    return (
        <Accordion.Item eventKey={eventKey}>
            {children}
        </Accordion.Item>
    )
}

export const AccordionHeaderComponent = ({children}) => {
    return (
        <Accordion.Header>{children}</Accordion.Header>
    )
}

export const AccordionBodyComponent = ({children}) => {
    return (
        <Accordion.Body>{children}</Accordion.Body>
    )
}
