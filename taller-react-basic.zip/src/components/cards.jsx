import React from 'react'
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

// function CardPage() {
//   return (
//     <Card style={{ width: '18rem' }}>
//       <Card.Img variant="top" src="https://fastly.picsum.photos/id/343/1600/900.jpg?hmac=4jA_jKk9hC_TjkrHMpLHPUxGEraLohQDjcyAQSxCwRc" />
//       <Card.Body>
//         <Card.Title>Card Title</Card.Title>
//         <Card.Text>
//           Some quick example text to build on the card title and make up the
//           bulk of the card's content.
//         </Card.Text>
//         <Button variant="primary">Go somewhere</Button>
//       </Card.Body>
//     </Card>
//   );
// }

// export default CardPage;

export const CardComponent = ({children}) => {
    return (
        <Card style={{ width:'100%' }}>
            {children}
        </Card>
    )
}
export const CardImageComponent = ({variant, src}) => {
    return(
        <Card.Img variant={variant} src={src} />
            
    )
}
export const CardBodyComponent = ({children}) => {
    return (
        <Card.Body>
            {children}
        </Card.Body>
    )
}
export const CardTitleComponent = ({children}) => {
    return (
        <Card.Title>{children}</Card.Title>   
    )
}
export const CardTextComponent = ({children}) => {
    return (
        <Card.Text>{children}</Card.Text>   
    )
}

export const CardButtonComponent = ({variant, children}) => {
    return (
        <Button variant={variant}>{children}</Button>   
    )
}