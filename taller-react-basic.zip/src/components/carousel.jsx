import React from 'react'

import { useState } from 'react';
import Carousel from 'react-bootstrap/Carousel';

function CarouselPage() {
  const [index, setIndex] = useState(0);

  const handleSelect = (selectedIndex) => {
    setIndex(selectedIndex);
  };

  return (
    <Carousel activeIndex={index} onSelect={handleSelect}>
      <Carousel.Item>
        <img 
            className="d-block w-100" 
            src="https://fastly.picsum.photos/id/343/1600/900.jpg?hmac=4jA_jKk9hC_TjkrHMpLHPUxGEraLohQDjcyAQSxCwRc" 
            alt=""
        />
        <Carousel.Caption>
          <h3>First slide label</h3>
          <p>Nulla vitae elit libero, a pharetra augue mollis interdum.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img 
            className="d-block w-100" 
            src="https://fastly.picsum.photos/id/11/2500/1667.jpg?hmac=xxjFJtAPgshYkysU_aqx2sZir-kIOjNR9vx0te7GycQ" 
            alt=""
        />
        <Carousel.Caption>
          <h3>Second slide label</h3>
          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        </Carousel.Caption>
      </Carousel.Item>
      <Carousel.Item>
      <img 
            className="d-block w-100" 
            src="https://fastly.picsum.photos/id/14/2500/1667.jpg?hmac=ssQyTcZRRumHXVbQAVlXTx-MGBxm6NHWD3SryQ48G-o" 
            alt=""
        />
        <Carousel.Caption>
          <h3>Third slide label</h3>
          <p>
            Praesent commodo cursus magna, vel scelerisque nisl consectetur.
          </p>
        </Carousel.Caption>
      </Carousel.Item>
    </Carousel>
  );
}

export default CarouselPage;



// export const CarouselComponent =({children}) => {
//     const [index, setIndex] = useState(0);

//     const handleSelect = (selectedIndex) => {
//       setIndex(selectedIndex);
//     };

//     return (
//         <Carousel activeIndex={index} onSelect={handleSelect}>
//             {children} 
//         </Carousel>
//     )
// }

// export const CarouselItemComponent = ({children, imgUrl, alt}) => {
//     return (
//         <Carousel.Item>
//             <img 
//                 className="d-block w-100" 
//                 src={imgUrl} 
//                 alt={alt}
//             />
//             {children}
//         </Carousel.Item>
        
//     )
// }

// export const CarouselCaptionComponent = (h3, p) => {
//     return (
//         <Carousel.Caption>
//             <h3>{h3}</h3>
//             <p>{p}</p>
//         </Carousel.Caption>   
//     )
// }