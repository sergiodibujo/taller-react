import { 
    AccordionComponent,
    AccordionItemComponent,
    AccordionHeaderComponent,
    AccordionBodyComponent } from '../components/accordion'

const AccordionPage = () => {
  return (
    <div>
        <AccordionComponent defaultActiveKey="1">
            <AccordionItemComponent eventKey="0">
                <AccordionHeaderComponent>Accordion Item #0</AccordionHeaderComponent>
                <AccordionBodyComponent>Lorem ipsum dolor sit amet, consectetur adipiscing elit</AccordionBodyComponent>
            </AccordionItemComponent>

            <AccordionItemComponent eventKey="1">
                <AccordionHeaderComponent>Accordion Item #1</AccordionHeaderComponent>
                <AccordionBodyComponent>Lorem ipsum dolor sit amet, consectetur adipiscing elit</AccordionBodyComponent>
            </AccordionItemComponent>
            
            <AccordionItemComponent eventKey="2">
                <AccordionHeaderComponent>Accordion Item #2</AccordionHeaderComponent>
                <AccordionBodyComponent>Lorem ipsum dolor sit amet, consectetur adipiscing elit</AccordionBodyComponent>
            </AccordionItemComponent>
            
            <AccordionItemComponent eventKey="3">
                <AccordionHeaderComponent>Accordion Item #3</AccordionHeaderComponent>
                <AccordionBodyComponent>Lorem ipsum dolor sit amet, consectetur adipiscing elit</AccordionBodyComponent>
            </AccordionItemComponent>
            
            <AccordionItemComponent eventKey="4">
                <AccordionHeaderComponent>Accordion Item #4</AccordionHeaderComponent>
                <AccordionBodyComponent>Lorem ipsum dolor sit amet, consectetur adipiscing elit</AccordionBodyComponent>
            </AccordionItemComponent>
            
            <AccordionItemComponent eventKey="5">
                <AccordionHeaderComponent>Accordion Item #5</AccordionHeaderComponent>
                <AccordionBodyComponent>Lorem ipsum dolor sit amet, consectetur adipiscing elit</AccordionBodyComponent>
            </AccordionItemComponent>
        </AccordionComponent>
    </div>
  )
}

export default AccordionPage