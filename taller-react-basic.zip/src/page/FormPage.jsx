import { useState } from "react"
import {
    FormComponent,
    FormGroupComponent,
    FormLabelComponent,
    FormControlComponent } from "../components/form"
import Button from 'react-bootstrap/Button';

function FormPage() {

    const [email, setEmail] = useState('');
    const [name, setName] = useState('');
    const [phone, setPhone] = useState(0);
    const [text, setText] = useState('');

  return (
    <FormComponent>
       <FormGroupComponent className="mb-3" controlId="formBasicEmail">
         <FormLabelComponent>Email address</FormLabelComponent>
         <FormControlComponent type="email" placeholder="name@example.com" onChange={(e) => setEmail(e.target.value)} value={email}/>
       </FormGroupComponent>
       
       <FormGroupComponent className="mb-3" controlId="formBasicName">
         <FormLabelComponent>Name</FormLabelComponent>
         <FormControlComponent type="text" placeholder="Your Name" onChange={(e) => setName(e.target.value)} value={name}/>
       </FormGroupComponent>

       <FormGroupComponent className="mb-3" controlId="formBasicPhone">
         <FormLabelComponent>Phone</FormLabelComponent>
         <FormControlComponent type="number" placeholder="Your Phone" onChange={(e) => setPhone(e.target.value)} value={phone}/>
       </FormGroupComponent>

       <FormGroupComponent className="mb-3" controlId="formBasicText">
         <FormLabelComponent>Example textarea</FormLabelComponent>
         <FormControlComponent as="textarea" rows={3} placeholder="Your Message" onChange={(e) => setText(e.target.value)} value={text}/>
       </FormGroupComponent>

       <Button type="submit">Send</Button>

     </FormComponent>
  )
}

export default FormPage