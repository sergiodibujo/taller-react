import { 
    NavBarComponent,
    NavBarBrandComponent,
    NavComponent,
    NavItemComponent
} from "../components/navbar";

const NavPage = () => {
    return (
        <>
            <NavBarComponent>
                <NavBarBrandComponent href="/">Design Templates</NavBarBrandComponent>
                <NavComponent className="me-auto">
                    <NavItemComponent href="/">Index</NavItemComponent>
                    <NavItemComponent href="/">About Us</NavItemComponent>
                    <NavItemComponent href="/">Contact</NavItemComponent>
                </NavComponent>
            </NavBarComponent>
        </>
    )
};

export default NavPage