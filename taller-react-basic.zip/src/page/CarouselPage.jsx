import { 
    CarouselComponent,
    CarouselItemComponent,
    CarouselCaptionComponent
} from '../components/carousel'
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import { Accordion } from 'react-bootstrap';

const CarouselPage = () => {
  return (

        <CarouselComponent className="my-3">
            <CarouselItemComponent
                imgUrl="https://fastly.picsum.photos/id/343/1600/900.jpg?hmac=4jA_jKk9hC_TjkrHMpLHPUxGEraLohQDjcyAQSxCwRc" 
                alt="Mi Alt">
                <CarouselCaptionComponent
                    h3="h3"
                    p="Body Text">
                </CarouselCaptionComponent>
            </CarouselItemComponent>
            <CarouselItemComponent
                imgUrl="https://fastly.picsum.photos/id/11/2500/1667.jpg?hmac=xxjFJtAPgshYkysU_aqx2sZir-kIOjNR9vx0te7GycQ" 
                alt="Mi Alt">
                <CarouselCaptionComponent
                    h3="h3"
                    p="Body Text">
                </CarouselCaptionComponent>
            </CarouselItemComponent>
            <CarouselItemComponent
                imgUrl="https://fastly.picsum.photos/id/14/2500/1667.jpg?hmac=ssQyTcZRRumHXVbQAVlXTx-MGBxm6NHWD3SryQ48G-o" 
                alt="Mi Alt">
                <CarouselCaptionComponent
                    h3="h3"
                    p="Body Text">
                </CarouselCaptionComponent>
            </CarouselItemComponent>
        </CarouselComponent>

  )
}

export default CarouselPage

