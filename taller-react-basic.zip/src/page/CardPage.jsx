import { 
     CardComponent,
     CardImageComponent,
     CardBodyComponent,
     CardTitleComponent,
     CardTextComponent,
     CardButtonComponent
 } from "../components/cards.jsx"
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';


const CardPage = () => {
  return (
    <>
    <Container className="my-3">
        <Row>
            <Col className="d-flex justify-content-center">
                <CardComponent>
                    <CardImageComponent
                        src="https://fastly.picsum.photos/id/343/1600/900.jpg?hmac=4jA_jKk9hC_TjkrHMpLHPUxGEraLohQDjcyAQSxCwRc"
                        variant="top"
                    />
                    <CardBodyComponent>
                        <CardTitleComponent>Title 1</CardTitleComponent>
                        <CardTextComponent>My Long Text</CardTextComponent>
                        <CardButtonComponent variant="primary">View</CardButtonComponent>
                    </CardBodyComponent>
                </CardComponent>
            </Col>
            <Col className="d-flex justify-content-center">
                <CardComponent>
                    <CardImageComponent
                        src="https://fastly.picsum.photos/id/343/1600/900.jpg?hmac=4jA_jKk9hC_TjkrHMpLHPUxGEraLohQDjcyAQSxCwRc"
                        variant="top"
                    />
                    <CardBodyComponent>
                        <CardTitleComponent>Title 1</CardTitleComponent>
                        <CardTextComponent>My Long Text</CardTextComponent>
                        <CardButtonComponent variant="primary">View</CardButtonComponent>
                    </CardBodyComponent>
                </CardComponent>
            </Col>
            <Col className="d-flex justify-content-center">
                <CardComponent>
                    <CardImageComponent
                        src="https://fastly.picsum.photos/id/343/1600/900.jpg?hmac=4jA_jKk9hC_TjkrHMpLHPUxGEraLohQDjcyAQSxCwRc"
                        variant="top"
                    />
                    <CardBodyComponent>
                        <CardTitleComponent>Title 1</CardTitleComponent>
                        <CardTextComponent>My Long Text</CardTextComponent>
                        <CardButtonComponent variant="primary">View</CardButtonComponent>
                    </CardBodyComponent>
                </CardComponent>
            </Col>
        </Row>
    </Container>
    </>
  )
}

export default CardPage
