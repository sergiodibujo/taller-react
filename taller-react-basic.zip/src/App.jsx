import { useState } from 'react'
// import viteLogo from '/vite.svg'
// import NavBarPage from './components/navbar'
import CarouselPage from './components/carousel'
// import CardPage from './components/cards'
// import AccordionPage from './components/accordion'
// import FormPage from './components/form'
import NavPage from './page/NavPage'
import CardPage from './page/CardPage';
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import AccordionPage from './page/AccordionPage';
import FormPage from './page/FormPage';

function App() {
  
  return (
    <div>
      <NavPage />
      <CarouselPage />
      
      <Container>
        <CardPage/>
        <Row>
          <Col>
            <AccordionPage/>
          </Col>
          <Col>
            <FormPage/>              
          </Col>
        </Row>
      </Container>
      
    </div>
  )
}

export default App
